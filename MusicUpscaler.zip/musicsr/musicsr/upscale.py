"""Chunked AudioSR inference + additive-highs reconstruction.

AudioSR facts that shape this code (from reading its source):
  * It is mono.  Stereo has to be handled here.
  * It works on 48 kHz audio padded to a multiple of 5.12 s and the README
    warns that >10.24 s per pass degrades quality, so long tracks are cut
    into 10.24 s chunks with a cross-faded overlap.
  * It normalises every input chunk to 0.5 peak and its output too, so
    absolute level is lost; we recover it by matching low-band RMS.
  * Its own post-processing already keeps the original content below the
    detected cutoff and only generates above it.  We go one step further
    and take ONLY the band above the cutoff from the model, adding it to
    the untouched original.  Everything you already had stays bit-exact
    (apart from the 48 kHz resample).
"""

from __future__ import annotations

import gc
import inspect
import os
import tempfile
import time
from dataclasses import dataclass, field

import numpy as np
from scipy.signal import butter, sosfiltfilt

from .audio_io import resample
from .cutoff import CutoffResult, detect_cutoff, needs_upscale

TARGET_SR = 48000
MODEL_BLOCK_S = 5.12          # AudioSR pads to multiples of this


@dataclass
class UpscaleResult:
    samples: np.ndarray            # (channels, n) float32 @ 48 kHz  — original + generated highs
    highs: np.ndarray              # (channels, n) float32 @ 48 kHz  — the generated highs alone
    cutoff: CutoffResult
    sample_rate: int = TARGET_SR
    skipped: bool = False          # True when nothing was run (cutoff already high, dry-run, silent)
    reason: str = ""
    chunks: int = 0
    model_seconds: float = 0.0     # wall time spent inside the model
    audio_seconds: float = 0.0
    peak_vram_mb: float = 0.0
    chunk_times: list[float] = field(default_factory=list)

    @property
    def realtime_factor(self) -> float:
        """>1 means faster than real time."""
        return self.audio_seconds / self.model_seconds if self.model_seconds else 0.0


def _sos_lp(fc: float, sr: int, order: int = 8):
    return butter(order, min(fc, sr / 2 * 0.999) / (sr / 2), btype="low", output="sos")


def _sos_hp(fc: float, sr: int, order: int = 8):
    return butter(order, min(fc, sr / 2 * 0.999) / (sr / 2), btype="high", output="sos")


def _rms(x: np.ndarray) -> float:
    return float(np.sqrt(np.mean(x.astype(np.float64) ** 2)) + 1e-12)


class Cancelled(Exception):
    pass


class Upscaler:
    """Holds the loaded model and the processing parameters.  Load once, process many."""

    def __init__(self, *, model_name: str = "basic", device: str = "auto",
                 ddim_steps: int = 50, guidance_scale: float = 3.5, seed: int = 42,
                 chunk_seconds: float = 10.24, overlap_seconds: float = 1.28,
                 stereo_mode: str = "mid", highs_gain_db: float = 0.0,
                 skip_above_hz: float = 19500.0, min_cliff_db: float = 12.0,
                 dry_run: bool = False):
        assert stereo_mode in ("mid", "dual")
        assert chunk_seconds >= 2 * overlap_seconds > 0, "chunk must be at least twice the overlap"
        self.model_name = model_name
        self.device = device
        self.ddim_steps = ddim_steps
        self.guidance_scale = guidance_scale
        self.seed = seed
        self.chunk_seconds = chunk_seconds
        self.overlap_seconds = overlap_seconds
        self.stereo_mode = stereo_mode
        self.highs_gain = 10 ** (highs_gain_db / 20.0)
        self.skip_above_hz = skip_above_hz
        self.min_cliff_db = min_cliff_db
        self.dry_run = dry_run
        self._model = None
        self._in_memory = False
        self._torch = None
        self.should_stop = None   # optional callable; checked between chunks

    # ------------------------------------------------------------------ model
    def load(self) -> None:
        if self.dry_run or self._model is not None:
            return
        import torch
        import audiosr
        from audiosr import build_model
        self._torch = torch
        torch.set_float32_matmul_precision("high")
        t0 = time.time()
        self._model = build_model(model_name=self.model_name, device=self.device)
        # git main has an in-memory path; PyPI 0.0.7 needs a temp WAV.
        try:
            from audiosr.pipeline import make_batch_for_super_resolution
            self._in_memory = "waveform" in inspect.signature(make_batch_for_super_resolution).parameters
        except Exception:
            self._in_memory = False
        print(f"[musicsr] AudioSR '{self.model_name}' loaded in {time.time() - t0:.1f}s "
              f"(in-memory chunks: {self._in_memory}, audiosr={getattr(audiosr, '__version__', '?')})")

    def device_info(self) -> dict:
        if self.dry_run:
            return {"device": "dry-run"}
        torch = self._torch
        if torch is None:
            import torch  # type: ignore
        if torch.cuda.is_available():
            p = torch.cuda.get_device_properties(0)
            return {"device": p.name, "vram_gb": round(p.total_memory / 2**30, 1),
                    "cuda": torch.version.cuda, "torch": torch.__version__}
        return {"device": "cpu", "torch": torch.__version__}

    def _run_model_chunk(self, mono48: np.ndarray) -> np.ndarray:
        """mono48: (n,) float32 @ 48k, n <= chunk.  Returns model output (n,) float32."""
        n = mono48.shape[0]
        import audiosr.pipeline as pl
        if self._in_memory:
            pl.seed_everything(self.seed)
            batch, duration = pl.make_batch_for_super_resolution(None, waveform=mono48[None, :])
            with self._torch.no_grad():
                out = self._model.generate_batch(
                    batch, unconditional_guidance_scale=self.guidance_scale,
                    ddim_steps=self.ddim_steps, duration=duration)
        else:
            import soundfile as sf
            fd, tmp = tempfile.mkstemp(suffix=".wav")
            os.close(fd)
            try:
                sf.write(tmp, mono48, TARGET_SR, subtype="FLOAT")
                out = pl.super_resolution(self._model, tmp, seed=self.seed,
                                          ddim_steps=self.ddim_steps,
                                          guidance_scale=self.guidance_scale,
                                          latent_t_per_second=12.8)
            finally:
                try:
                    os.remove(tmp)
                except OSError:
                    pass
        out = np.asarray(out, dtype=np.float32).reshape(-1)
        if out.shape[0] < n:
            out = np.pad(out, (0, n - out.shape[0]))
        return out[:n]

    # -------------------------------------------------------------- pipeline
    def _generate_highs(self, mono48: np.ndarray, fc: float, stats: UpscaleResult) -> np.ndarray:
        """Chunk -> model -> keep only > fc, rescaled to source units -> overlap-add."""
        n = mono48.shape[0]
        chunk = int(round(self.chunk_seconds * TARGET_SR))
        ov = int(round(self.overlap_seconds * TARGET_SR))
        hop = chunk - ov
        highs = np.zeros(n, dtype=np.float32)
        weight = np.zeros(n, dtype=np.float32)
        win = np.hanning(2 * ov).astype(np.float32)
        fade_in, fade_out = win[:ov], win[ov:]

        sos_lp = _sos_lp(fc * 0.9, TARGET_SR)
        sos_hp = _sos_hp(fc, TARGET_SR)
        silence_peak = 10 ** (-70 / 20)

        # Full-length chunks; the last one is anchored to the end so no short tail
        # goes through the model on its own (any extra overlap is just averaged).
        if n <= chunk:
            starts = [0]
        else:
            starts = list(range(0, n - chunk, hop)) + [n - chunk]
        for s in starts:
            if self.should_stop is not None and self.should_stop():
                raise Cancelled()
            e = min(s + chunk, n)
            x = mono48[s:e]
            w = np.ones(e - s, dtype=np.float32)
            if s > 0:
                w[:ov] = fade_in
            if e < n:
                w[-ov:] = fade_out

            peak = float(np.max(np.abs(x)))
            if peak < silence_peak or self.dry_run:
                gen = np.zeros_like(x)
            else:
                t0 = time.time()
                y = self._run_model_chunk(x)
                dt = time.time() - t0
                stats.chunk_times.append(dt)
                stats.model_seconds += dt
                # bring model output back to the source's absolute level via the low band
                g = _rms(sosfiltfilt(sos_lp, x)) / _rms(sosfiltfilt(sos_lp, y))
                g = float(np.clip(g, 1e-3, 1e3))
                gen = sosfiltfilt(sos_hp, y * g).astype(np.float32)
            highs[s:e] += gen * w
            weight[s:e] += w
            stats.chunks += 1
            if self._torch is not None and not self.dry_run:
                gc.collect()
                if self._torch.cuda.is_available():
                    self._torch.cuda.empty_cache()

        weight[weight == 0] = 1.0
        return highs / weight

    def process(self, samples: np.ndarray, sr: int,
                cutoff: CutoffResult | None = None) -> UpscaleResult:
        """samples: (channels, n) float32 at any sample rate.  Returns 48 kHz result."""
        if samples.ndim == 1:
            samples = samples[None, :]
        cutoff = cutoff or detect_cutoff(samples, sr)
        x48 = resample(samples, sr, TARGET_SR).astype(np.float32)
        ch, n = x48.shape
        res = UpscaleResult(samples=x48, highs=np.zeros_like(x48), cutoff=cutoff,
                            audio_seconds=n / TARGET_SR)

        ok, why = needs_upscale(cutoff, self.skip_above_hz, self.min_cliff_db)
        if not ok:
            res.skipped, res.reason = True, why
            return res

        self.load()
        if self._torch is not None and self._torch.cuda.is_available():
            self._torch.cuda.reset_peak_memory_stats()

        fc = cutoff.cutoff_hz
        if ch == 1 or self.stereo_mode == "mid":
            mid = x48.mean(axis=0)
            h = self._generate_highs(mid, fc, res)
            highs = np.repeat(h[None, :], ch, axis=0)
        else:  # dual: each channel through the model, same seed
            highs = np.stack([self._generate_highs(x48[c], fc, res) for c in range(ch)])

        highs *= self.highs_gain
        res.highs = highs.astype(np.float32)
        res.samples = np.clip(x48 + res.highs, -1.0, 1.0).astype(np.float32)
        if self._torch is not None and self._torch.cuda.is_available():
            res.peak_vram_mb = self._torch.cuda.max_memory_allocated() / 2**20
        if self.dry_run:
            res.reason = "dry-run: model not executed"
        return res
