@echo off
cd /d "%~dp0"
if exist .venv\Scripts\activate.bat goto run
echo Run setup.bat first.
pause
exit /b 1
:run
call .venv\Scripts\activate.bat
python app.py
if errorlevel 1 pause
