#!/usr/bin/env python
"""bench.py — measure what AudioSR actually does to YOUR files on YOUR GPU.

    python bench.py "C:\\Music\\some 128k.mp3" "C:\\Music\\a cd rip.flac" --seconds 30

For every input it reports the detected spectral cutoff, whether the model
would run at all, seconds of model time per second of audio, and peak VRAM.
It also writes three files per track into --out so you can A/B them:

    <name>.original.flac   the source resampled to 48 kHz (a fair reference)
    <name>.upscaled.flac   original + generated highs
    <name>.highs.flac      the generated highs alone — turn it up and listen to
                           exactly what the model is adding

Use --cutoff-only to just scan cutoffs (no GPU, instant) — handy to run over a
whole folder first with --scan to learn what your library is made of.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from musicsr import Upscaler, decode_audio, detect_cutoff, needs_upscale, write_flac
from musicsr.audio_io import AUDIO_EXTS


def fmt_rate(r: float) -> str:
    return f"{r:.2f}x realtime" if r else "n/a"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("inputs", nargs="+", help="audio files (or folders with --scan)")
    ap.add_argument("--out", default="bench_out", help="where A/B files go")
    ap.add_argument("--seconds", type=float, default=30.0, help="only process the first N seconds (0 = whole track)")
    ap.add_argument("--steps", type=int, default=50, help="DDIM steps (AudioSR default 50; 20-30 is much faster)")
    ap.add_argument("--guidance", type=float, default=3.5)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--stereo", choices=["mid", "dual"], default="mid",
                    help="mid = one model pass on L+R, highs added to both (fast); dual = each channel separately")
    ap.add_argument("--highs-gain-db", type=float, default=0.0, help="trim the generated highs, e.g. -3")
    ap.add_argument("--skip-above", type=float, default=19500.0, help="skip files whose cutoff is already >= this Hz")
    ap.add_argument("--min-cliff", type=float, default=12.0,
                    help="require a step of at least this many dB at the cutoff (a brick wall); 0 = any roll-off")
    ap.add_argument("--force", action="store_true", help="run the model even if the cutoff says it's pointless")
    ap.add_argument("--cutoff-only", action="store_true", help="no model, just report cutoffs")
    ap.add_argument("--scan", action="store_true", help="treat inputs as folders and walk them (implies --cutoff-only)")
    ap.add_argument("--model", choices=["basic", "speech"], default="basic")
    ap.add_argument("--device", default="auto")
    ap.add_argument("--json", default=None, help="also dump results to this JSON file")
    args = ap.parse_args()

    files: list[Path] = []
    for inp in args.inputs:
        p = Path(inp)
        if p.is_dir():
            files += sorted(q for q in p.rglob("*") if q.suffix.lower() in AUDIO_EXTS)
        elif p.exists():
            files.append(p)
        else:
            print(f"!! not found: {p}", file=sys.stderr)
    if not files:
        print("nothing to do", file=sys.stderr)
        return 1
    cutoff_only = args.cutoff_only or args.scan

    up = Upscaler(model_name=args.model, device=args.device, ddim_steps=args.steps,
                  guidance_scale=args.guidance, seed=args.seed, stereo_mode=args.stereo,
                  highs_gain_db=args.highs_gain_db,
                  skip_above_hz=1e9 if args.force else args.skip_above,
                  min_cliff_db=0.0 if args.force else args.min_cliff, dry_run=cutoff_only)
    if not cutoff_only:
        up.load()
        print("[bench] device:", up.device_info())

    out_dir = Path(args.out)
    rows = []
    hdr = f"{'file':<48} {'sr':>6} {'codec':<6} {'kbps':>5} {'cutoff':>8} {'cliff':>6} {'lossy?':>6} {'run?':>4}"
    if not cutoff_only:
        hdr += f" {'chunks':>6} {'model s':>8} {'speed':>16} {'VRAM MB':>8}"
    print(hdr)
    print("-" * len(hdr))

    for f in files:
        try:
            t0 = time.time()
            dec = decode_audio(f, max_seconds=None if (args.seconds <= 0 or cutoff_only) else args.seconds)
            cut = detect_cutoff(dec.samples, dec.sample_rate)
            kbps = f"{dec.bit_rate // 1000}" if dec.bit_rate else "-"
            row = {"file": str(f), "sample_rate": dec.sample_rate, "channels": dec.channels,
                   "codec": dec.codec, "bit_rate": dec.bit_rate, "duration": dec.duration,
                   **cut.as_dict(), "looks_lossy": cut.looks_lossy}
            would, why = needs_upscale(cut, args.skip_above, args.min_cliff)
            row["would_upscale"], row["decision"] = would, why
            line = (f"{f.name[:48]:<48} {dec.sample_rate:>6} {dec.codec[:6]:<6} {kbps:>5} "
                    f"{cut.cutoff_hz:>7.0f}Hz {cut.cliff_db:>5.0f}dB {'yes' if cut.looks_lossy else 'no':>6} "
                    f"{'yes' if would else 'no':>4}")
            if not cutoff_only:
                res = up.process(dec.samples, dec.sample_rate, cutoff=cut)
                row.update({"skipped": res.skipped, "reason": res.reason, "chunks": res.chunks,
                            "model_seconds": round(res.model_seconds, 2),
                            "audio_seconds": round(res.audio_seconds, 2),
                            "realtime_factor": round(res.realtime_factor, 3),
                            "peak_vram_mb": round(res.peak_vram_mb),
                            "chunk_times": [round(t, 2) for t in res.chunk_times],
                            "wall_seconds": round(time.time() - t0, 2)})
                if res.skipped:
                    line += f"   skipped: {res.reason}"
                else:
                    line += (f" {res.chunks:>6} {res.model_seconds:>8.1f} {fmt_rate(res.realtime_factor):>16} "
                             f"{res.peak_vram_mb:>8.0f}")
                    stem = out_dir / f.stem
                    write_flac(stem.with_suffix(".original.flac"), res.samples - res.highs, res.sample_rate, 24)
                    write_flac(stem.with_suffix(".upscaled.flac"), res.samples, res.sample_rate, 24)
                    write_flac(stem.with_suffix(".highs.flac"), res.highs, res.sample_rate, 24)
            print(line)
            rows.append(row)
        except Exception as e:  # keep going, report at the end
            print(f"{f.name[:48]:<48} ERROR: {e}")
            rows.append({"file": str(f), "error": str(e)})

    if not cutoff_only:
        ran = [r for r in rows if r.get("chunks")]
        if ran:
            tot_model = sum(r["model_seconds"] for r in ran)
            tot_audio = sum(r["audio_seconds"] for r in ran)
            print(f"\n[bench] {len(ran)} track(s) through the model: {tot_audio:.0f}s of audio in "
                  f"{tot_model:.0f}s of GPU time = {fmt_rate(tot_audio / tot_model if tot_model else 0)}")
            per_chunk = [t for r in ran for t in r["chunk_times"]]
            if per_chunk:
                print(f"[bench] per 10.24 s chunk: min {min(per_chunk):.1f}s  median "
                      f"{sorted(per_chunk)[len(per_chunk)//2]:.1f}s  max {max(per_chunk):.1f}s  "
                      f"(steps={args.steps}, stereo={args.stereo})")
                est = (tot_model / tot_audio) if tot_audio else 0
                print(f"[bench] rough cost for a 4-minute track: {est * 240 / 60:.1f} min; "
                      f"for 1,000 such tracks: {est * 240 * 1000 / 3600:.0f} h")
            print(f"[bench] A/B files written to {out_dir.resolve()}")
    if args.scan:
        lossy = sum(1 for r in rows if r.get("looks_lossy"))
        would = sum(1 for r in rows if r.get("would_upscale"))
        mins = sum(r.get("duration", 0) for r in rows if r.get("would_upscale")) / 60
        print(f"\n[scan] {len(rows)} files, {lossy} look brick-wall lossy, {would} would be upscaled "
              f"({mins:.0f} min of audio) with --skip-above {args.skip_above:.0f} --min-cliff {args.min_cliff:.0f}")

    if args.json:
        Path(args.json).write_text(json.dumps(rows, indent=2))
        print(f"[bench] results saved to {args.json}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
