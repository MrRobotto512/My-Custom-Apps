"""Copy metadata (and cover art) from any source file to the output FLAC."""

from __future__ import annotations

from pathlib import Path

import mutagen
from mutagen.flac import FLAC, Picture
from mutagen.id3 import ID3
from mutagen.mp4 import MP4

# EasyID3-style keys that exist across formats and map cleanly to Vorbis comments.
EASY_KEYS = [
    "title", "artist", "albumartist", "album", "date", "originaldate", "genre",
    "tracknumber", "discnumber", "composer", "performer", "comment", "isrc",
    "bpm", "compilation", "musicbrainz_trackid", "musicbrainz_albumid",
    "musicbrainz_artistid", "musicbrainz_albumartistid", "replaygain_track_gain",
    "replaygain_album_gain", "lyrics", "label", "organization", "copyright",
]


def _extract_pictures(src: Path) -> list[Picture]:
    """Pull embedded cover art out of MP3 (APIC), FLAC (pictures) or MP4 (covr)."""
    pics: list[Picture] = []
    try:
        f = mutagen.File(str(src))
    except Exception:
        return pics
    if f is None:
        return pics

    if isinstance(f, FLAC):
        return list(f.pictures)

    if isinstance(f, MP4):
        for cover in f.tags.get("covr", []) if f.tags else []:
            p = Picture()
            p.type = 3  # front cover
            p.mime = "image/png" if cover.imageformat == 14 else "image/jpeg"
            p.data = bytes(cover)
            pics.append(p)
        return pics

    # MP3 / anything with ID3
    try:
        id3 = ID3(str(src))
    except Exception:
        return pics
    for apic in id3.getall("APIC"):
        p = Picture()
        p.type = apic.type or 3
        p.mime = apic.mime or "image/jpeg"
        p.desc = apic.desc or ""
        p.data = apic.data
        pics.append(p)
    return pics


def copy_tags(src: Path, dst_flac: Path, extra: dict[str, str] | None = None) -> int:
    """Copy tags src -> dst_flac.  Returns number of fields written."""
    src, dst_flac = Path(src), Path(dst_flac)
    try:
        easy = mutagen.File(str(src), easy=True)
    except Exception:
        easy = None

    out = FLAC(str(dst_flac))
    out.delete()
    n = 0
    if easy is not None and easy.tags is not None:
        for key in EASY_KEYS:
            try:
                vals = easy.tags.get(key)
            except Exception:
                vals = None
            if vals:
                out[key] = [str(v) for v in vals]
                n += 1

    for pic in _extract_pictures(src):
        out.add_picture(pic)

    for k, v in (extra or {}).items():
        out[k] = str(v)
    out.save()
    return n
