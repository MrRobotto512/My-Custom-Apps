@echo off
cd /d "%~dp0"
echo ==== Music Upscaler setup - one time ====
echo.

where py >nul 2>&1
if errorlevel 1 goto nopy
py -3.10 -c "print('Python 3.10 OK')" 2>nul
if errorlevel 1 goto no310

if exist .venv\Scripts\activate.bat goto havevenv
echo Creating virtual environment...
py -3.10 -m venv .venv
if errorlevel 1 goto fail
:havevenv
call .venv\Scripts\activate.bat

echo.
echo [1/3] Installing PyTorch with CUDA - about 2.5 GB, this takes a while...
python -m pip install --upgrade pip
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cu121
if errorlevel 1 goto fail

echo.
echo [2/3] Installing AudioSR and the rest...
pip install -r requirements.txt
if errorlevel 1 goto fail

echo.
echo [3/3] Checking ffmpeg...
where ffmpeg >nul 2>&1
if not errorlevel 1 goto haveff
if exist ffmpeg.exe goto haveff
echo ffmpeg not found - installing with winget...
winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
echo If winget failed: download https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip
echo and copy ffmpeg.exe and ffprobe.exe from its bin folder into this folder, next to app.py.
:haveff

echo.
python -c "import torch; print('GPU:', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'NOT FOUND - CUDA torch did not install or the NVIDIA driver is too old')"
python -c "import audiosr; print('AudioSR OK')"
echo.
echo Setup finished. Double-click MusicUpscaler.bat to run the app.
pause
exit /b 0

:nopy
echo Python launcher not found. Install Python 3.10 64-bit from
echo https://www.python.org/downloads/release/python-31011/
echo and tick "Add python.exe to PATH" in the installer, then run this again.
pause
exit /b 1

:no310
echo Python 3.10 is not installed. AudioSR's dependencies need exactly 3.10.
echo Get the 64-bit installer here: https://www.python.org/downloads/release/python-31011/
pause
exit /b 1

:fail
echo.
echo Setup failed - see the error above. Send me the last lines of this window.
pause
exit /b 1
