"""musicsr — AudioSR-based music library upscaler (shared core).

Pipeline for one track:
    decode (ffmpeg) -> cutoff detection -> [skip?] -> resample to 48 kHz
    -> chunked AudioSR inference -> add ONLY the generated highs back onto
       the untouched original -> write FLAC -> copy tags + cover art

The "additive highs" reconstruction matters: AudioSR re-synthesises the
whole signal through a vocoder and normalises loudness.  We never ship
that.  Below the detected cutoff the output is the original audio,
sample for sample; above it we add what the model generated, scaled to
match.  That keeps the stereo image, dynamics and loudness of the source
intact and makes A/B listening honest.
"""

from .audio_io import decode_audio, write_flac, write_mp3, resample, get_ffmpeg
from .cutoff import detect_cutoff, needs_upscale, CutoffResult
from .tags import copy_tags
from .upscale import Upscaler, UpscaleResult

__all__ = [
    "decode_audio", "write_flac", "write_mp3", "resample", "get_ffmpeg",
    "detect_cutoff", "needs_upscale", "CutoffResult",
    "copy_tags",
    "Upscaler", "UpscaleResult",
]
