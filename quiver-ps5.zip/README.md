# Quiver for PS5

A homebrew library and updater that runs **on a jailbroken PS5**, inspired by
[Quiver Launcher](https://github.com/tgeorgiadis/quiver-launcher). It keeps a library of apps
hosted on GitHub or GitLab, installs and updates them from their releases, and starts them —
all from the console.

It's a native payload (`quiver.elf`) with a web UI. On start it opens itself in the PS5 browser.
You can also use it from your phone or PC at `http://<console-ip>:8095`.

## What it does

- **Library** with search and tag filters, update badges, and per-app details.
- **Catalog** of known PS5 homebrew (websrv, ftpsrv, shsrv, klogsrv, Crispy Doom, DevilutionX,
  RetroArch, ScummVM, FFplay, prospero-win and more). Add anything else by `owner/repo` or URL.
- **Install / update / uninstall** from GitHub or GitLab releases. Pre-releases are included by
  default, because most PS5 projects only publish those.
  - Zips with `eboot.elf` or `homebrew.js` go to `/data/homebrew/<folder>`, where websrv and
    ShadowMountPlus also find them. Updates overwrite the app's files but **keep files you
    added** (WADs, ROMs, saves).
  - `.elf` payloads go to `/data/quiver/payloads/<app>/`.
  - `.pkg` files are saved to `/data/pkg` for your package installer.
- **Launch**
  - Payloads are sent to the ELF loader on `127.0.0.1:9021`.
  - Homebrew apps start through websrv's homebrew loader. If websrv isn't running and you
    installed it through Quiver, Quiver starts it first.
  - `homebrew.js` menus (e.g. Crispy Doom's Doom/Heretic/Hexen/Strife picker) work inside
    Quiver. "Open in websrv" is always available as a fallback.
- **Find existing apps**: Settings → *Find apps already in /data/homebrew* adds folders you
  copied by FTP.
- **Controller friendly**: big targets and D-pad/arrow navigation. Circle/Escape closes dialogs.

## Requirements

- A PS5 running a jailbreak with an **ELF loader on port 9021** (elfldr, or the loader that
  comes with etaHEN/kstuff). Built and tested against the ps5-payload-dev SDK.
- Network access on the console (GitHub/GitLab over HTTPS uses the PS5's own TLS stack).
- For homebrew apps: **websrv** (install it from Quiver's Catalog first).

## Install

1. Load your jailbreak and ELF loader.
2. Send the payload from a PC on the same network:
   ```sh
   nc -q0 <console-ip> 9021 < quiver.elf      # or: socat -u FILE:quiver.elf TCP:<console-ip>:9021
   ```
   You can also use any payload sender app.
3. A notification shows the address, and the browser opens Quiver.
4. Open **Catalog** → install **websrv**, then whatever else you like.

Data lives in `/data/quiver` (`apps.json`, `settings.json`). Send `quiver.elf` again after a
reboot; your library is kept.

## Settings

| Setting | Default | Notes |
| --- | --- | --- |
| Quiver port | 8095 | Applies on next start |
| ELF loader port | 9021 | |
| websrv port | 8080 | |
| Open browser on start | on | |
| Check for updates on start | on | |
| GitHub token | – | Optional. Without one GitHub allows 60 checks/hour. Never sent back to the browser. |
| Extra catalog URL | – | A JSON file shaped like `catalog/catalog.json` |

## Build

```sh
# PS5 payload (needs https://github.com/ps5-payload-dev/sdk, clang-18, lld-18)
export PS5_PAYLOAD_SDK=/opt/ps5-payload-sdk
make                       # -> quiver.elf
make send PS5_HOST=<ip>    # send it to the console

# Linux test build: same code, runs in ./sandbox, HTTPS through curl
make host && QUIVER_SANDBOX=$PWD/sandbox ./quiver-host
```

## Layout

| Path | What it is |
| --- | --- |
| `src/main.c` | Startup |
| `src/server.c`, `src/api.c` | HTTP server and JSON API |
| `src/library.c` | `apps.json` / `settings.json` |
| `src/releases.c` | GitHub/GitLab release lookup and asset picking |
| `src/jobs.c` | Background download/extract/install/uninstall/update-check worker |
| `src/launch.c` | elfldr and websrv launching |
| `src/ps5/` | Console code: libSceHttp client, notifications, browser |
| `src/host/` | Linux test-build code |
| `ui/` | The web UI (embedded into the payload at build time) |
| `catalog/catalog.json` | Built-in catalog |

## Status

The logic and UI were tested end to end with the Linux build against mock GitHub, elfldr and
websrv services. The console-specific pieces haven't been run on hardware yet:
- the `libSceHttp` client, modelled on websrv's
- notifications and opening the browser, from the SDK samples

If something fails on your console, the notification text and the job message in the UI say
which step failed.

## License

GPLv3 (the ps5-payload-sdk is GPLv3). Bundles cJSON (MIT) and miniz (MIT). Not affiliated with
Quiver Launcher or Sony.
