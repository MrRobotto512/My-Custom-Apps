"""Spectral cutoff detection.

Answers: "how high does this file's real content go, and does it end in a
brick wall?"  A 128 kbps MP3 is usually low-passed at ~16 kHz, a 192 kbps
one at ~18-19 kHz, a good 320 kbps MP3 or CD rip reaches ~20 kHz+.
Anything already near the Nyquist limit has nothing for a super-resolution
model to add, so the worker skips it.

Method
------
Long-term average power spectrum (dB) of the middle of the track, lightly
smoothed.  We then look for the biggest *step* in that spectrum: the level
in the ~300 Hz just below a frequency minus the level in the ~300 Hz just
above it.  A lossy encoder's low-pass produces a 30-60 dB step inside a
few hundred hertz; a natural analogue roll-off never does.  If a step of
at least `min_cliff_db` exists, that is the cutoff.  If not, the file has
a natural roll-off and we report where the content drops 90 dB below its
peak as the effective bandwidth, with a small cliff value.

The worker's default rule (see `needs_upscale`) is: process a file only if
it has a real cliff below the skip threshold.  Files with a gentle natural
roll-off are left alone unless you ask for them explicitly.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict

import numpy as np
from scipy.signal import get_window


@dataclass
class CutoffResult:
    cutoff_hz: float          # highest frequency with real content
    nyquist_hz: float
    floor_db: float           # quietest bins (dB re full-scale sine)
    peak_db: float            # loudest bin
    cliff_db: float           # size of the step at the cutoff (bigger = brick wall)
    ratio: float              # cutoff / nyquist, 0..1

    def as_dict(self) -> dict:
        return asdict(self)

    @property
    def looks_lossy(self) -> bool:
        """A steep cliff well below Nyquist is the fingerprint of a lossy codec."""
        return self.cliff_db >= 20 and self.ratio < 0.93


def needs_upscale(cut: CutoffResult, skip_above_hz: float = 19500.0, min_cliff_db: float = 12.0) -> tuple[bool, str]:
    """Decide whether running the model makes sense.  Returns (decision, reason)."""
    if cut.cutoff_hz < 2000:
        return False, "no usable content (silent or corrupt?)"
    if cut.cutoff_hz >= skip_above_hz:
        return False, f"cutoff {cut.cutoff_hz:.0f} Hz already >= {skip_above_hz:.0f} Hz"
    if cut.cliff_db < min_cliff_db:
        return False, f"natural roll-off (cliff {cut.cliff_db:.0f} dB < {min_cliff_db:.0f} dB), nothing to restore"
    return True, f"brick wall at {cut.cutoff_hz:.0f} Hz ({cut.cliff_db:.0f} dB cliff)"


def _avg_power_db(x: np.ndarray, sr: int, n_fft: int, seconds: float) -> np.ndarray:
    """Mean power spectrum in dB of a mono signal, analysed over the middle `seconds`."""
    n = x.shape[0]
    take = min(n, int(seconds * sr))
    start = max(0, (n - take) // 2)
    seg = x[start:start + take]
    if seg.shape[0] < n_fft:
        seg = np.pad(seg, (0, n_fft - seg.shape[0]))
    hop = n_fft // 2
    win = get_window("hann", n_fft, fftbins=True).astype(np.float32)
    nframes = 1 + (seg.shape[0] - n_fft) // hop
    idx = np.arange(n_fft)[None, :] + hop * np.arange(nframes)[:, None]
    frames = seg[idx] * win
    spec = np.fft.rfft(frames, axis=1)
    power = (np.abs(spec) ** 2).mean(axis=0)
    power /= (win.sum() ** 2) / 4.0     # full-scale sine ~ 0 dB
    return 10.0 * np.log10(power + 1e-20)


def _moving_mean(x: np.ndarray, w: int) -> np.ndarray:
    if w <= 1:
        return x
    k = np.ones(w) / w
    return np.convolve(np.pad(x, (w // 2, w - 1 - w // 2), mode="edge"), k, mode="valid")


def detect_cutoff(samples: np.ndarray, sr: int, *, n_fft: int = 4096,
                  analyse_seconds: float = 60.0, min_cliff_db: float = 12.0,
                  step_hz: float = 300.0) -> CutoffResult:
    """samples: (channels, n) float32.  Analyses a mono mix of the middle of the track."""
    mono = samples.mean(axis=0) if samples.ndim == 2 else samples
    mono = mono.astype(np.float32, copy=False)

    db = _avg_power_db(mono, sr, n_fft, analyse_seconds)
    freqs = np.fft.rfftfreq(n_fft, 1.0 / sr)
    nyq = sr / 2.0
    hz_per_bin = sr / n_fft

    valid = (freqs >= 40.0) & (freqs < nyq)
    peak_db = float(db[valid].max())
    floor_db = float(np.percentile(db[valid], 5))
    abs_floor = max(floor_db, peak_db - 130.0)

    smooth = _moving_mean(db, max(1, int(round(100.0 / hz_per_bin))))
    W = max(2, int(round(step_hz / hz_per_bin)))

    # Step size at every bin: mean level just below minus mean level just above.
    cs = np.concatenate([[0.0], np.cumsum(smooth)])
    k = np.arange(len(smooth))
    lo_start, hi_end = np.clip(k - W, 0, None), np.clip(k + 1 + W, None, len(smooth))
    below = (cs[k] - cs[lo_start]) / np.maximum(k - lo_start, 1)
    above = (cs[hi_end] - cs[k + 1]) / np.maximum(hi_end - (k + 1), 1)
    drop = below - above
    search = (freqs >= 3000.0) & (freqs <= nyq - step_hz) & (k - W >= 0)
    drop = np.where(search, drop, -np.inf)

    kbest = int(np.argmax(drop))
    if drop[kbest] >= min_cliff_db:
        cut_idx, cliff_db = kbest, float(drop[kbest])
    else:
        # Natural roll-off: report where content falls 90 dB under the peak.
        thresh = max(peak_db - 90.0, abs_floor)
        above_thresh = np.where(valid & (smooth > thresh))[0]
        cut_idx = int(above_thresh.max()) if above_thresh.size else 0
        cliff_db = float(drop[cut_idx]) if np.isfinite(drop[cut_idx]) else 0.0
        cliff_db = max(cliff_db, 0.0)

    cutoff_hz = float(freqs[cut_idx])
    return CutoffResult(cutoff_hz=cutoff_hz, nyquist_hz=nyq, floor_db=floor_db, peak_db=peak_db,
                        cliff_db=cliff_db, ratio=cutoff_hz / nyq if nyq else 0.0)
