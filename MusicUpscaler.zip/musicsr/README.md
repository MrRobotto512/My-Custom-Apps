# Music Upscaler

**The app:** run `setup.bat` once, then double-click `MusicUpscaler.bat`. Pick your music folder, pick an
output folder, press Start. Every MP3 (or M4A/FLAC/whatever) comes out as a **320 kbps MP3** with the
same name, folder layout, tags and cover art, with AI-restored highs above the old encoder's cutoff.

Files that are already full-bandwidth (CD rips, proper 320k MP3s) are skipped by default because
there is nothing to restore in them; untick the box if you want them re-encoded anyway.

Straight talk on bitrate: re-encoding a 128k file at 320k on its own does not put anything back.
What makes the output better is the AudioSR step in between, which regenerates the top end the
128k encoder threw away; 320k is just a container big enough to keep that. The FLAC option keeps
it losslessly if you prefer.

Headless: `python app.py --cli "D:\Music" "D:\Music (upscaled)"` (add `--best`, `--flac`, `--all`, `--soft`).

---

# Under the hood: bench + batch worker

Two entry points on top of one small library (`musicsr/`):

| script | what it is for |
|---|---|
| `bench.py` | Run a handful of tracks, get real numbers for your 2080 Ti, and A/B the result |
| `upscale_worker.py` | Resumable batch job over a whole library (scan → cutoff detection → upscale → FLAC → tags) |

Both share the same pipeline, so what you measure in the bench is what the worker does.

## Windows setup (RTX 2080 Ti)

1. Install **Python 3.10** (64-bit) from python.org — not 3.12, AudioSR's pinned deps have no wheels there.
2. Install **ffmpeg** and put `ffmpeg.exe` + `ffprobe.exe` on your PATH (or set `MUSICSR_FFMPEG`).
   Winget: `winget install Gyan.FFmpeg`
3. Make sure your NVIDIA driver is current (anything from the last couple of years is fine for CUDA 12.x).
4. In this folder:

```bat
py -3.10 -m venv .venv
.venv\Scripts\activate
pip install --upgrade pip
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cu121
pip install -r requirements.txt
python -c "import torch; print(torch.cuda.get_device_name(0), torch.version.cuda)"
```

The last line should print `NVIDIA GeForce RTX 2080 Ti`. If it prints nothing / errors, the CUDA
build of torch didn't install — rerun the torch line.

The first model run downloads the ~2 GB `audiosr_basic` checkpoint from Hugging Face into your
user cache.

## Step 1 — see what your library is made of (no GPU, seconds)

```bat
python bench.py "D:\Music" --scan
```

Prints one line per file: sample rate, codec, bitrate, detected **cutoff** frequency, how sharp the
**cliff** above it is, and whether it looks brick-wall lossy. Files with a cutoff at or above
19.5 kHz (CD rips, good 320k MP3s) have nothing to gain and are skipped by default.

## Step 2 — real numbers on the 2080 Ti

Pick 4–5 representative files (a FLAC, a 320k MP3, a 128k MP3, something old) and run:

```bat
python bench.py "D:\Music\a.mp3" "D:\Music\b.flac" "D:\Music\c.mp3" --seconds 30
```

You get model seconds per audio second, VRAM, a projected cost per 4-minute track and per 1,000
tracks, and three files per track in `bench_out\`:

* `*.original.flac` — source resampled to 48 kHz (fair reference)
* `*.upscaled.flac` — original + generated highs
* `*.highs.flac` — **only** what the model added. Play this loud. This is the honest answer to
  "is it doing anything I want?"

Knobs worth trying in the bench before committing to a library run:

* `--steps 25` — roughly 2× faster than the default 50; listen for whether you can tell.
* `--stereo dual` — runs L and R separately (2× cost). Default `mid` runs one pass on L+R and adds
  the same highs to both channels; for hallucinated air above 16 kHz that is usually fine.
* `--highs-gain-db -3` — the generated top end often reads as too bright; this trims only the
  added part, the original is untouched.
* `--force` — run the model on a file the cutoff check would skip, to hear what it does to
  already-full-bandwidth audio (spoiler: it should add almost nothing).

## Step 3 — batch worker

```bat
python upscale_worker.py "D:\Music" "D:\Music_48k" --dry-run
python upscale_worker.py "D:\Music" "D:\Music_48k" --limit 20
python upscale_worker.py "D:\Music" "D:\Music_48k"
```

* Output mirrors the source folder tree as 48 kHz FLAC (16-bit + dither by default, `--bit-depth 24`).
* Tags and embedded cover art are copied (MP3/ID3, M4A, FLAC, OGG…), plus a `MUSICSR` tag recording
  what was done so you can tell processed files apart later.
* Progress is in `<out>\musicsr_manifest.sqlite`. Ctrl+C any time; rerunning resumes. `--redo`
  reprocesses, `--retry-failed` retries errors.
* `--skipped copy` copies files that didn't need upscaling into the output tree unchanged, so the
  output is a complete library instead of only the changed files.
* By default only files with a real brick wall (a step of at least 12 dB at the cutoff, `--min-cliff`)
  below 19.5 kHz (`--skip-above`) are processed. Vinyl/tape rips and old masters with a gentle natural
  roll-off are left alone; pass `--min-cliff 0` if you want those "filled in" too.

## How the reconstruction works (why this isn't just "run AudioSR")

AudioSR is mono, normalises everything to 0.5 peak, and re-synthesises the signal through a
vocoder. Shipping its raw output would change loudness and stereo image on every track. Instead,
`musicsr/upscale.py`:

1. resamples the original to 48 kHz,
2. runs the model on 10.24 s chunks with a 1.28 s cross-fade (AudioSR's own sweet spot),
3. rescales each chunk's output to the source level by matching low-band RMS,
4. high-passes the model output at the detected cutoff so **only generated content** survives,
5. adds that to the untouched original.

Below the cutoff the output is your original audio; above it is what the model made up. That is
also why `*.highs.flac` exists.

## Turning this into a Windows app

Everything above is the worker. The app is a thin layer on top of it: a folder picker, the
scan table from `bench.py --scan`, a queue driven by the manifest, and a progress bar fed by the
per-file log lines. PySide6 + PyInstaller is the least-friction route; the worker can run in a
`QThread` or as a subprocess with the same CLI. Don't build that until the bench says the
result is worth it.

## Known limits / TODO

* Decode/encode is serialised with the GPU work; overlapping them in a thread would recover
  roughly 10–20 % on a long run.
* The cutoff detector looks at the middle 60 s of each track; a file that is mostly silence or
  has a very quiet intro can be misjudged (it will then be skipped rather than mangled).
* AudioSR's own README says MP3 artefacts ("spectral holes") and heavy reverb degrade results —
  the 128k files that benefit most are also the ones it is most likely to get wrong. Listen.
