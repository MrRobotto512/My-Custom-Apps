#!/usr/bin/env python
"""upscale_worker.py — resumable batch upscaler for a music library.

    python upscale_worker.py "D:\\Music" "D:\\Music_48k" [options]

For every audio file under the source root (mirrored into the output root as
.flac):  scan -> cutoff detection -> skip if already full-bandwidth ->
AudioSR (chunked, GPU) -> original + generated highs -> 48 kHz FLAC -> tags.

Progress lives in <out>/musicsr_manifest.sqlite, so you can Ctrl+C and rerun;
finished files are not redone unless the source changed or --redo is given.
Run with --dry-run first: it decodes and classifies everything without
touching the GPU or writing audio, and tells you how much work is queued.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sqlite3
import sys
import time
from datetime import datetime
from pathlib import Path

from musicsr import Upscaler, copy_tags, decode_audio, detect_cutoff, needs_upscale, write_flac
from musicsr.audio_io import AUDIO_EXTS

SCHEMA = """
CREATE TABLE IF NOT EXISTS files (
    src TEXT PRIMARY KEY,
    src_size INTEGER, src_mtime REAL,
    status TEXT,              -- done | skipped | failed
    out TEXT,
    cutoff_hz REAL, cliff_db REAL, looks_lossy INTEGER,
    chunks INTEGER, model_seconds REAL, audio_seconds REAL,
    params TEXT, error TEXT, updated_at TEXT
);
"""


class Manifest:
    def __init__(self, path: Path):
        self.db = sqlite3.connect(str(path))
        self.db.executescript(SCHEMA)

    def get(self, src: Path):
        cur = self.db.execute("SELECT src_size, src_mtime, status, out, params FROM files WHERE src=?", (str(src),))
        return cur.fetchone()

    def put(self, src: Path, **cols):
        cols["src"] = str(src)
        cols["updated_at"] = datetime.now().isoformat(timespec="seconds")
        keys = ", ".join(cols)
        qs = ", ".join("?" * len(cols))
        self.db.execute(f"INSERT OR REPLACE INTO files ({keys}) VALUES ({qs})", list(cols.values()))
        self.db.commit()

    def summary(self) -> dict:
        cur = self.db.execute("SELECT status, COUNT(*), COALESCE(SUM(model_seconds),0), COALESCE(SUM(audio_seconds),0) FROM files GROUP BY status")
        return {r[0]: {"n": r[1], "model_s": r[2], "audio_s": r[3]} for r in cur.fetchall()}


def params_hash(args) -> str:
    keys = ["steps", "guidance", "seed", "stereo", "highs_gain_db", "skip_above", "min_cliff", "model", "bit_depth"]
    blob = json.dumps({k: getattr(args, k) for k in keys}, sort_keys=True)
    return hashlib.sha1(blob.encode()).hexdigest()[:10]


def out_path_for(src: Path, src_root: Path, out_root: Path) -> Path:
    return (out_root / src.relative_to(src_root)).with_suffix(".flac")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("src_root")
    ap.add_argument("out_root")
    ap.add_argument("--steps", type=int, default=50)
    ap.add_argument("--guidance", type=float, default=3.5)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--stereo", choices=["mid", "dual"], default="mid")
    ap.add_argument("--highs-gain-db", type=float, default=0.0)
    ap.add_argument("--skip-above", type=float, default=19500.0,
                    help="files whose cutoff is already >= this Hz are not upscaled")
    ap.add_argument("--min-cliff", type=float, default=12.0,
                    help="only upscale files with a step of at least this many dB at the cutoff (brick wall). "
                         "0 = also process files with a natural roll-off below --skip-above")
    ap.add_argument("--skipped", choices=["ignore", "copy"], default="ignore",
                    help="what to do with files that don't need upscaling: leave out, or copy unchanged so the output tree is a full library")
    ap.add_argument("--bit-depth", type=int, choices=[16, 24], default=16)
    ap.add_argument("--model", choices=["basic", "speech"], default="basic")
    ap.add_argument("--device", default="auto")
    ap.add_argument("--limit", type=int, default=0, help="stop after N files that needed the model (0 = no limit)")
    ap.add_argument("--redo", action="store_true", help="reprocess files already marked done")
    ap.add_argument("--retry-failed", action="store_true")
    ap.add_argument("--dry-run", action="store_true", help="classify only: no GPU, no output audio, manifest untouched")
    args = ap.parse_args()

    src_root, out_root = Path(args.src_root).resolve(), Path(args.out_root).resolve()
    if not src_root.is_dir():
        print(f"source root not found: {src_root}", file=sys.stderr)
        return 1
    if out_root == src_root or src_root in out_root.parents:
        print("output root must not be inside the source root", file=sys.stderr)
        return 1
    out_root.mkdir(parents=True, exist_ok=True)
    manifest = Manifest(out_root / "musicsr_manifest.sqlite")
    phash = params_hash(args)

    files = sorted(p for p in src_root.rglob("*") if p.is_file() and p.suffix.lower() in AUDIO_EXTS)
    print(f"[worker] {len(files)} audio files under {src_root}")

    up = Upscaler(model_name=args.model, device=args.device, ddim_steps=args.steps,
                  guidance_scale=args.guidance, seed=args.seed, stereo_mode=args.stereo,
                  highs_gain_db=args.highs_gain_db, skip_above_hz=args.skip_above,
                  min_cliff_db=args.min_cliff, dry_run=args.dry_run)

    counts = {"done": 0, "skipped": 0, "failed": 0, "resumed": 0, "queued": 0}
    t_start = time.time()
    processed_with_model = 0
    try:
        for i, src in enumerate(files, 1):
            st = src.stat()
            prev = manifest.get(src)
            dst = out_path_for(src, src_root, out_root)
            if prev and not args.dry_run:
                p_size, p_mtime, p_status, p_out, p_params = prev
                unchanged = p_size == st.st_size and abs(p_mtime - st.st_mtime) < 1
                if p_status == "done" and unchanged and Path(p_out).exists() and not args.redo:
                    counts["resumed"] += 1
                    continue
                if p_status == "skipped" and unchanged and p_params == phash and not args.redo:
                    counts["resumed"] += 1
                    continue
                if p_status == "failed" and not args.retry_failed and unchanged:
                    counts["resumed"] += 1
                    continue

            tag = f"[{i}/{len(files)}] {src.relative_to(src_root)}"
            try:
                dec = decode_audio(src)
                cut = detect_cutoff(dec.samples, dec.sample_rate)
                needs, reason = needs_upscale(cut, args.skip_above, args.min_cliff)
                base = dict(src_size=st.st_size, src_mtime=st.st_mtime, cutoff_hz=cut.cutoff_hz,
                            cliff_db=cut.cliff_db, looks_lossy=int(cut.looks_lossy),
                            audio_seconds=dec.duration, params=phash)

                if not needs:
                    if args.dry_run:
                        counts["skipped"] += 1
                        print(f"{tag}: skip ({reason})")
                        continue
                    if args.skipped == "copy":
                        dst_copy = out_root / src.relative_to(src_root)
                        dst_copy.parent.mkdir(parents=True, exist_ok=True)
                        if not dst_copy.exists():
                            shutil.copy2(src, dst_copy)
                        manifest.put(src, status="skipped", out=str(dst_copy), error=reason, **base)
                    else:
                        manifest.put(src, status="skipped", out=None, error=reason, **base)
                    counts["skipped"] += 1
                    print(f"{tag}: skip ({reason})")
                    continue

                if args.dry_run:
                    counts["queued"] += 1
                    print(f"{tag}: WOULD upscale ({reason}, {dec.duration/60:.1f} min)")
                    continue

                t0 = time.time()
                res = up.process(dec.samples, dec.sample_rate, cutoff=cut)
                write_flac(dst, res.samples, res.sample_rate, args.bit_depth)
                ntags = copy_tags(src, dst, extra={
                    "MUSICSR": f"audiosr:{args.model} steps={args.steps} stereo={args.stereo} "
                               f"cutoff={cut.cutoff_hz:.0f}Hz highs_gain={args.highs_gain_db}dB",
                    "MUSICSR_SOURCE": str(src.relative_to(src_root)),
                })
                manifest.put(src, status="done", out=str(dst), chunks=res.chunks,
                             model_seconds=res.model_seconds, error=None, **base)
                counts["done"] += 1
                processed_with_model += 1
                rt = res.realtime_factor
                print(f"{tag}: done in {time.time()-t0:.0f}s ({rt:.2f}x realtime, {res.chunks} chunks, "
                      f"cutoff {cut.cutoff_hz:.0f} Hz, {ntags} tag fields)")
                if args.limit and processed_with_model >= args.limit:
                    print(f"[worker] --limit {args.limit} reached")
                    break
            except KeyboardInterrupt:
                raise
            except Exception as e:
                counts["failed"] += 1
                print(f"{tag}: FAILED {e}")
                if not args.dry_run:
                    manifest.put(src, status="failed", out=None, error=str(e)[:500],
                                 src_size=st.st_size, src_mtime=st.st_mtime, params=phash)
    except KeyboardInterrupt:
        print("\n[worker] interrupted — rerun the same command to resume")

    el = time.time() - t_start
    print(f"\n[worker] done={counts['done']} skipped={counts['skipped']} failed={counts['failed']} "
          f"resumed={counts['resumed']} queued(dry)={counts['queued']} in {el/60:.1f} min")
    if not args.dry_run:
        s = manifest.summary()
        d = s.get("done")
        if d and d["model_s"]:
            print(f"[worker] lifetime: {d['n']} upscaled, {d['audio_s']/3600:.1f} h of audio, "
                  f"{d['audio_s']/d['model_s']:.2f}x realtime average")
    return 0


if __name__ == "__main__":
    sys.exit(main())
