#!/usr/bin/env python
"""Music Upscaler — pick a folder of MP3s, get restored 320 kbps MP3s in another folder.

Double-click MusicUpscaler.bat to run (after setup.bat once).  Everything the
GUI does is in `run_job()` so it can also run headless:  python app.py --cli IN OUT
"""

from __future__ import annotations

import queue
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from musicsr import Upscaler, decode_audio, detect_cutoff, needs_upscale, resample, write_flac, write_mp3
from musicsr.audio_io import AUDIO_EXTS, get_ffmpeg
from musicsr.upscale import Cancelled

APP_TITLE = "Music Upscaler (AudioSR)"


@dataclass
class JobConfig:
    src: Path
    dst: Path
    steps: int = 25                 # 25 = fast, 50 = best
    output: str = "mp3"             # "mp3" (320 kbps) or "flac"
    skip_fullband: bool = True      # leave files that already reach ~20 kHz alone
    highs_gain_db: float = 0.0      # 0 = normal, -3 = softer
    overwrite: bool = False


MODEL_SIZE_MB = 6300   # haoheliu/audiosr_basic pytorch_model.bin is ~6.2 GB


def _model_cache_mb() -> float | None:
    """Bytes of the AudioSR checkpoint on disk so far (grows while downloading)."""
    try:
        from huggingface_hub.constants import HF_HUB_CACHE
        d = Path(HF_HUB_CACHE) / "models--haoheliu--audiosr_basic"
        if not d.exists():
            return 0.0
        return sum(p.stat().st_size for p in d.rglob("*") if p.is_file()) / 2**20
    except Exception:
        return None


def load_model_with_feedback(up: Upscaler, log, should_stop) -> None:
    """up.load() with a progress line every 10 s so the GUI never looks frozen."""
    before = _model_cache_mb() or 0.0
    if before < MODEL_SIZE_MB * 0.95:
        log(f"First run: downloading the AudioSR model ({MODEL_SIZE_MB/1024:.1f} GB) to "
            f"C:\\Users\\<you>\\.cache\\huggingface\\hub  ... this can take a long time on Wi-Fi.")
    else:
        log("Loading AudioSR model from disk (6 GB checkpoint, 1-3 minutes)...")
    done = threading.Event()
    t0 = time.time()

    def heartbeat():
        last = before
        while not done.wait(10):
            mb = _model_cache_mb()
            el = time.time() - t0
            if mb is None:
                log(f"  still loading... {el:.0f}s")
            elif mb < MODEL_SIZE_MB * 0.95:
                rate = (mb - last) / 10.0
                eta = f", ~{(MODEL_SIZE_MB - mb) / rate / 60:.0f} min left" if rate > 0.5 else ""
                log(f"  downloading: {mb/1024:.2f} / {MODEL_SIZE_MB/1024:.1f} GB ({rate:.1f} MB/s{eta})")
                last = mb
            else:
                log(f"  download complete, loading into memory / GPU... {el:.0f}s")

    threading.Thread(target=heartbeat, daemon=True).start()
    try:
        up.load()
    finally:
        done.set()
    log(f"Model ready on {up.device_info().get('device')} ({time.time()-t0:.0f}s)")


def run_job(cfg: JobConfig, log, progress, should_stop) -> dict:
    """log(str); progress(done, total, current_name, eta_seconds); should_stop() -> bool."""
    files = sorted(p for p in cfg.src.rglob("*") if p.is_file() and p.suffix.lower() in AUDIO_EXTS)
    total = len(files)
    stats = {"done": 0, "skipped": 0, "failed": 0, "exists": 0, "audio_s": 0.0, "model_s": 0.0}
    if not files:
        log("No audio files found in that folder.")
        return stats
    log(f"Found {total} audio files. Using ffmpeg at {get_ffmpeg()}")

    up = Upscaler(ddim_steps=cfg.steps, stereo_mode="mid", highs_gain_db=cfg.highs_gain_db,
                  skip_above_hz=19500.0 if cfg.skip_fullband else 1e9,
                  min_cliff_db=12.0 if cfg.skip_fullband else 0.0)
    up.should_stop = should_stop
    ext = ".mp3" if cfg.output == "mp3" else ".flac"
    t_start = time.time()

    for i, f in enumerate(files):
        if should_stop():
            log("Stopped.")
            break
        rel = f.relative_to(cfg.src)
        out = (cfg.dst / rel).with_suffix(ext)
        eta = None
        if stats["done"] and stats["model_s"]:
            per_file = (time.time() - t_start) / max(1, i)
            eta = per_file * (total - i)
        progress(i, total, str(rel), eta)

        if out.exists() and not cfg.overwrite:
            stats["exists"] += 1
            continue
        try:
            dec = decode_audio(f)
            cut = detect_cutoff(dec.samples, dec.sample_rate)
            ok, why = needs_upscale(cut, up.skip_above_hz, up.min_cliff_db)
            if not ok:
                log(f"skip   {rel}  ({why})")
                stats["skipped"] += 1
                continue
            if up._model is None and not up.dry_run:
                try:
                    load_model_with_feedback(up, log, should_stop)
                except Exception as e:
                    msg = str(e)
                    if "No module named" in msg:
                        mod = msg.split("'")[1] if "'" in msg else "?"
                        pipname = {"sklearn": "scikit-learn", "PIL": "pillow", "yaml": "pyyaml"}.get(mod, mod)
                        log(f"ERROR: the AudioSR install is missing the Python package '{mod}'. Fix: open a command "
                            f"prompt in this folder and run   .venv\\Scripts\\pip install {pipname}   then press Start again.")
                    else:
                        log(f"ERROR: could not load the AudioSR model: {msg}")
                    log("Stopping - nothing can be processed until the model loads.")
                    stats["failed"] = total - i
                    break
            t0 = time.time()
            res = up.process(dec.samples, dec.sample_rate, cutoff=cut)
            if cfg.output == "mp3":
                # back to the source rate so the file is a drop-in replacement
                y = resample(res.samples, res.sample_rate, dec.sample_rate)
                write_mp3(out, y, dec.sample_rate, src=f, bitrate="320k")
            else:
                write_flac(out, res.samples, res.sample_rate, 16)
                from musicsr import copy_tags
                copy_tags(f, out, extra={"MUSICSR": f"audiosr steps={cfg.steps} cutoff={cut.cutoff_hz:.0f}Hz"})
            stats["done"] += 1
            stats["audio_s"] += res.audio_seconds
            stats["model_s"] += res.model_seconds
            log(f"done   {rel}  (cutoff {cut.cutoff_hz/1000:.1f} kHz, {time.time()-t0:.0f}s, "
                f"{res.realtime_factor:.2f}x realtime)")
        except Cancelled:
            log("Stopped.")
            for part in out.parent.glob(out.stem + ".part*"):
                part.unlink(missing_ok=True)
            break
        except Exception as e:
            stats["failed"] += 1
            log(f"FAILED {rel}: {e}")

    progress(total, total, "", 0)
    el = time.time() - t_start
    log(f"Finished: {stats['done']} upscaled, {stats['skipped']} skipped (already full-bandwidth), "
        f"{stats['exists']} already existed, {stats['failed']} failed, in {el/60:.1f} min.")
    if stats["model_s"]:
        log(f"GPU speed: {stats['audio_s']/stats['model_s']:.2f}x realtime.")
    return stats


# ----------------------------------------------------------------------------- GUI
def gui() -> None:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    root = tk.Tk()
    root.title(APP_TITLE)
    root.geometry("760x560")
    root.minsize(640, 460)

    src_var = tk.StringVar()
    dst_var = tk.StringVar()
    quality_var = tk.StringVar(value="fast")
    output_var = tk.StringVar(value="mp3")
    skip_var = tk.BooleanVar(value=True)
    highs_var = tk.StringVar(value="normal")
    overwrite_var = tk.BooleanVar(value=False)

    msgs: queue.Queue = queue.Queue()
    state = {"thread": None, "stop": False}

    frm = ttk.Frame(root, padding=12)
    frm.pack(fill="both", expand=True)
    frm.columnconfigure(1, weight=1)

    def browse(var, title):
        d = filedialog.askdirectory(title=title)
        if d:
            var.set(d)
            if var is src_var and not dst_var.get():
                dst_var.set(str(Path(d).parent / (Path(d).name + " (upscaled)")))

    ttk.Label(frm, text="Music folder:").grid(row=0, column=0, sticky="w", pady=3)
    ttk.Entry(frm, textvariable=src_var).grid(row=0, column=1, sticky="ew", padx=6)
    ttk.Button(frm, text="Browse…", command=lambda: browse(src_var, "Pick the folder with your MP3s")).grid(row=0, column=2)

    ttk.Label(frm, text="Output folder:").grid(row=1, column=0, sticky="w", pady=3)
    ttk.Entry(frm, textvariable=dst_var).grid(row=1, column=1, sticky="ew", padx=6)
    ttk.Button(frm, text="Browse…", command=lambda: browse(dst_var, "Where to put the upscaled files")).grid(row=1, column=2)

    opts = ttk.LabelFrame(frm, text="Options", padding=8)
    opts.grid(row=2, column=0, columnspan=3, sticky="ew", pady=8)
    ttk.Label(opts, text="Quality:").grid(row=0, column=0, sticky="w")
    ttk.Radiobutton(opts, text="Fast (25 steps)", variable=quality_var, value="fast").grid(row=0, column=1, sticky="w")
    ttk.Radiobutton(opts, text="Best (50 steps, 2× slower)", variable=quality_var, value="best").grid(row=0, column=2, sticky="w")
    ttk.Label(opts, text="Output:").grid(row=1, column=0, sticky="w")
    ttk.Radiobutton(opts, text="MP3 320 kbps", variable=output_var, value="mp3").grid(row=1, column=1, sticky="w")
    ttk.Radiobutton(opts, text="FLAC 48 kHz (lossless)", variable=output_var, value="flac").grid(row=1, column=2, sticky="w")
    ttk.Label(opts, text="Added highs:").grid(row=2, column=0, sticky="w")
    ttk.Radiobutton(opts, text="Normal", variable=highs_var, value="normal").grid(row=2, column=1, sticky="w")
    ttk.Radiobutton(opts, text="Softer (−3 dB)", variable=highs_var, value="soft").grid(row=2, column=2, sticky="w")
    ttk.Checkbutton(opts, text="Skip files that are already full-bandwidth (CD rips, good 320k MP3s) — recommended",
                    variable=skip_var).grid(row=3, column=0, columnspan=3, sticky="w", pady=(6, 0))
    ttk.Checkbutton(opts, text="Overwrite files that already exist in the output folder",
                    variable=overwrite_var).grid(row=4, column=0, columnspan=3, sticky="w")

    btns = ttk.Frame(frm)
    btns.grid(row=3, column=0, columnspan=3, sticky="ew")
    start_btn = ttk.Button(btns, text="Start")
    stop_btn = ttk.Button(btns, text="Stop", state="disabled")
    start_btn.pack(side="left")
    stop_btn.pack(side="left", padx=6)
    status = ttk.Label(btns, text="Idle")
    status.pack(side="left", padx=12)

    bar = ttk.Progressbar(frm, mode="determinate")
    bar.grid(row=4, column=0, columnspan=3, sticky="ew", pady=6)

    logbox = tk.Text(frm, height=14, wrap="word", state="disabled")
    logbox.grid(row=5, column=0, columnspan=3, sticky="nsew")
    frm.rowconfigure(5, weight=1)
    sb = ttk.Scrollbar(frm, command=logbox.yview)
    sb.grid(row=5, column=3, sticky="ns")
    logbox.configure(yscrollcommand=sb.set)

    def log(msg: str):
        msgs.put(("log", msg))

    def progress(done, total, name, eta):
        msgs.put(("prog", (done, total, name, eta)))

    def pump():
        try:
            while True:
                kind, payload = msgs.get_nowait()
                if kind == "log":
                    logbox.configure(state="normal")
                    logbox.insert("end", payload + "\n")
                    logbox.see("end")
                    logbox.configure(state="disabled")
                elif kind == "prog":
                    done, total, name, eta = payload
                    bar["maximum"] = max(1, total)
                    bar["value"] = done
                    eta_s = f" — about {eta/60:.0f} min left" if eta else ""
                    status.configure(text=f"{done}/{total} {name}{eta_s}" if name else f"{done}/{total}")
                elif kind == "finished":
                    start_btn.configure(state="normal")
                    stop_btn.configure(state="disabled")
                    status.configure(text="Finished" if not state["stop"] else "Stopped")
        except queue.Empty:
            pass
        root.after(150, pump)

    def worker(cfg: JobConfig):
        try:
            run_job(cfg, log, progress, lambda: state["stop"])
        except Exception as e:  # never let the thread die silently
            log(f"ERROR: {e}")
        finally:
            msgs.put(("finished", None))

    def start():
        src, dst = Path(src_var.get().strip('" ')), Path(dst_var.get().strip('" '))
        if not src.is_dir():
            messagebox.showerror(APP_TITLE, "Pick the folder with your music first.")
            return
        if not dst_var.get().strip():
            messagebox.showerror(APP_TITLE, "Pick an output folder.")
            return
        if dst == src or src in dst.parents:
            messagebox.showerror(APP_TITLE, "The output folder must not be inside the music folder.")
            return
        try:
            get_ffmpeg()
        except RuntimeError as e:
            messagebox.showerror(APP_TITLE, str(e))
            return
        dst.mkdir(parents=True, exist_ok=True)
        cfg = JobConfig(src=src, dst=dst, steps=25 if quality_var.get() == "fast" else 50,
                        output=output_var.get(), skip_fullband=skip_var.get(),
                        highs_gain_db=-3.0 if highs_var.get() == "soft" else 0.0,
                        overwrite=overwrite_var.get())
        state["stop"] = False
        start_btn.configure(state="disabled")
        stop_btn.configure(state="normal")
        status.configure(text="Starting…")
        logbox.configure(state="normal"); logbox.delete("1.0", "end"); logbox.configure(state="disabled")
        state["thread"] = threading.Thread(target=worker, args=(cfg,), daemon=True)
        state["thread"].start()

    def stop():
        state["stop"] = True
        status.configure(text="Stopping after the current chunk…")
        stop_btn.configure(state="disabled")

    start_btn.configure(command=start)
    stop_btn.configure(command=stop)

    def on_close():
        if state["thread"] and state["thread"].is_alive():
            if not messagebox.askyesno(APP_TITLE, "A job is running. Quit anyway?"):
                return
            state["stop"] = True
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    pump()
    root.mainloop()


def cli(argv: list[str]) -> int:
    import argparse
    ap = argparse.ArgumentParser(description="headless mode")
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--best", action="store_true", help="50 steps instead of 25")
    ap.add_argument("--flac", action="store_true")
    ap.add_argument("--all", action="store_true", help="don't skip full-bandwidth files")
    ap.add_argument("--soft", action="store_true", help="added highs -3 dB")
    ap.add_argument("--overwrite", action="store_true")
    a = ap.parse_args(argv)
    cfg = JobConfig(Path(a.src), Path(a.dst), steps=50 if a.best else 25,
                    output="flac" if a.flac else "mp3", skip_fullband=not a.all,
                    highs_gain_db=-3.0 if a.soft else 0.0, overwrite=a.overwrite)
    cfg.dst.mkdir(parents=True, exist_ok=True)

    def prog(done, total, name, eta):
        if name:
            print(f"[{done+1}/{total}] {name}" + (f"  (~{eta/60:.0f} min left)" if eta else ""))
    run_job(cfg, print, prog, lambda: False)
    return 0


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--cli":
        sys.exit(cli(sys.argv[2:]))
    gui()
