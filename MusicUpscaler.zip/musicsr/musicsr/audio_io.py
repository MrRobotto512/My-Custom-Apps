"""Decoding / encoding / resampling.

Decoding goes through the ffmpeg CLI so every format in a real music
library (MP3, AAC/M4A, FLAC, OGG, Opus, WMA, WAV, APE, ...) just works.
On Windows put ffmpeg.exe on PATH or set MUSICSR_FFMPEG=C:\\path\\to\\ffmpeg.exe.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import soundfile as sf

AUDIO_EXTS = {".mp3", ".m4a", ".aac", ".flac", ".ogg", ".oga", ".opus",
              ".wma", ".wav", ".aif", ".aiff", ".ape", ".wv", ".mp4", ".alac"}


def _find_ffmpeg_windows() -> str | None:
    """Look in the usual places a Windows install lands when PATH wasn't refreshed."""
    import glob
    pats = []
    local = os.environ.get("LOCALAPPDATA")
    if local:
        pats.append(os.path.join(local, "Microsoft", "WinGet", "Packages", "Gyan.FFmpeg*", "**", "bin", "ffmpeg.exe"))
        pats.append(os.path.join(local, "Microsoft", "WinGet", "Links", "ffmpeg.exe"))
    for root in ("C:\\ffmpeg", "C:\\Program Files\\ffmpeg", "C:\\Program Files (x86)\\ffmpeg", "C:\\tools\\ffmpeg"):
        pats.append(os.path.join(root, "**", "ffmpeg.exe"))
    here = Path(__file__).resolve().parent.parent
    pats.append(str(here / "ffmpeg" / "**" / "ffmpeg.exe"))
    pats.append(str(here / "ffmpeg.exe"))
    for pat in pats:
        hits = glob.glob(pat, recursive=True)
        if hits:
            return hits[0]
    return None


def get_ffmpeg() -> str:
    exe = os.environ.get("MUSICSR_FFMPEG") or shutil.which("ffmpeg")
    if not exe and os.name == "nt":
        exe = _find_ffmpeg_windows()
    if not exe:
        raise RuntimeError(
            "ffmpeg not found. Run setup.bat, or download ffmpeg and put ffmpeg.exe next to app.py."
        )
    return exe


def get_ffprobe() -> str | None:
    ff = get_ffmpeg()
    cand = Path(ff).with_name("ffprobe" + Path(ff).suffix)
    if cand.exists():
        return str(cand)
    return shutil.which("ffprobe")


@dataclass
class DecodedAudio:
    samples: np.ndarray      # float32, shape (channels, n_samples), range about -1..1
    sample_rate: int
    codec: str = ""
    bit_rate: int | None = None   # bits/s as reported by the container, if any

    @property
    def channels(self) -> int:
        return self.samples.shape[0]

    @property
    def duration(self) -> float:
        return self.samples.shape[1] / self.sample_rate


def probe(path: Path) -> dict:
    """Return sample_rate / channels / codec / bit_rate via ffprobe (best effort)."""
    fp = get_ffprobe()
    info: dict = {}
    if not fp:
        return info
    try:
        out = subprocess.run(
            [fp, "-v", "error", "-select_streams", "a:0", "-show_entries",
             "stream=sample_rate,channels,codec_name,bit_rate:format=bit_rate,duration",
             "-of", "json", str(path)],
            capture_output=True, text=True, check=True,
        ).stdout
        j = json.loads(out)
        s = (j.get("streams") or [{}])[0]
        f = j.get("format") or {}
        info = {
            "sample_rate": int(s.get("sample_rate") or 0),
            "channels": int(s.get("channels") or 0),
            "codec": s.get("codec_name", ""),
            "bit_rate": int(s.get("bit_rate") or f.get("bit_rate") or 0) or None,
            "duration": float(f.get("duration") or 0),
        }
    except Exception:
        pass
    return info


def decode_audio(path: Path, max_seconds: float | None = None) -> DecodedAudio:
    """Decode any audio file to float32 at its native sample rate."""
    path = Path(path)
    info = probe(path)
    sr = info.get("sample_rate") or 0
    ch = info.get("channels") or 0

    cmd = [get_ffmpeg(), "-v", "error", "-nostdin", "-i", str(path)]
    if max_seconds:
        cmd += ["-t", f"{max_seconds:.3f}"]
    # Keep native rate/channels unless ffprobe failed, in which case force stereo/44.1k
    if not sr:
        sr, ch = 44100, 2
        cmd += ["-ar", str(sr), "-ac", str(ch)]
    cmd += ["-f", "f32le", "-acodec", "pcm_f32le", "-"]

    proc = subprocess.run(cmd, capture_output=True, check=False)
    if proc.returncode != 0 or not proc.stdout:
        raise RuntimeError(f"ffmpeg failed on {path.name}: {proc.stderr.decode(errors='replace')[:400]}")

    data = np.frombuffer(proc.stdout, dtype=np.float32)
    if ch <= 0:
        ch = 2
    n = (len(data) // ch) * ch
    samples = data[:n].reshape(-1, ch).T.copy()  # (channels, samples)
    return DecodedAudio(samples=samples, sample_rate=sr,
                        codec=info.get("codec", ""), bit_rate=info.get("bit_rate"))


def resample(x: np.ndarray, sr_in: int, sr_out: int) -> np.ndarray:
    """High-quality resample of (channels, n) float32. Uses soxr if installed."""
    if sr_in == sr_out:
        return x
    try:
        import soxr  # type: ignore
        return soxr.resample(x.T, sr_in, sr_out, quality="VHQ").T.astype(np.float32)
    except ImportError:
        from math import gcd
        from scipy.signal import resample_poly
        g = gcd(sr_in, sr_out)
        y = resample_poly(x, sr_out // g, sr_in // g, axis=1, window=("kaiser", 14.0))
        return y.astype(np.float32)


def write_flac(path: Path, samples: np.ndarray, sample_rate: int, bit_depth: int = 16) -> None:
    """Write (channels, n) float32 to FLAC atomically (temp file + rename)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".part")
    subtype = {16: "PCM_16", 24: "PCM_24"}[bit_depth]
    data = np.clip(samples.T, -1.0, 1.0)
    if bit_depth == 16:
        # TPDF dither so added highs don't turn into truncation distortion
        lsb = 1.0 / 32768.0
        rng = np.random.default_rng(0)
        data = data + (rng.random(data.shape) + rng.random(data.shape) - 1.0) * lsb
        data = np.clip(data, -1.0, 1.0)
    sf.write(str(tmp), data, sample_rate, format="FLAC", subtype=subtype)
    os.replace(tmp, path)


def write_mp3(path: Path, samples: np.ndarray, sample_rate: int, *, src: Path | None = None,
              bitrate: str = "320k", out_rate: int | None = None) -> None:
    """Encode (channels, n) float32 to MP3 with libmp3lame, copying tags + cover art from `src`."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.stem + ".part.mp3")
    ch = samples.shape[0]

    def cmd(with_cover: bool) -> list[str]:
        c = [get_ffmpeg(), "-v", "error", "-y", "-nostdin",
             "-f", "f32le", "-ar", str(sample_rate), "-ac", str(ch), "-i", "pipe:0"]
        if src is not None:
            c += ["-i", str(src), "-map", "0:a", "-map_metadata", "1"]
            if with_cover:
                c += ["-map", "1:v?", "-c:v", "copy", "-disposition:v", "attached_pic"]
        c += ["-c:a", "libmp3lame", "-b:a", bitrate, "-id3v2_version", "3", "-write_id3v1", "1"]
        if out_rate:
            c += ["-ar", str(out_rate)]
        return c + [str(tmp)]

    data = np.ascontiguousarray(np.clip(samples.T, -1.0, 1.0), dtype=np.float32).tobytes()
    proc = subprocess.run(cmd(True), input=data, capture_output=True)
    if proc.returncode != 0 and src is not None:
        proc = subprocess.run(cmd(False), input=data, capture_output=True)   # tags only
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg mp3 encode failed: {proc.stderr.decode(errors='replace')[:400]}")
    os.replace(tmp, path)
